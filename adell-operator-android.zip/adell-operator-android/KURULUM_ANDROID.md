# Adell Operatör – Android uygulaması

Bu klasör hazır bir Android (Capacitor) projesidir. Uygulama tamamen çevrimdışı
çalışır: ekranlar, yazı tipleri ve simgeler uygulamanın içindedir.

Uygulama özellikleri:
- Tam ekran açılır (durum ve gezinme çubukları gizli), ekran kapanmaz.
- Tablet dik tutulursa dikey, yatay tutulursa yatay düzen gelir.
- Gün içi veriler tablette saklanır, ertesi gün sıfırlanır.
- Sesli kalite / performans uyarıları çalışır.

## Yol A – Bilgisayara kurulum gerektirmeden (GitHub ile)
1. GitHub'da yeni (özel) bir depo açın ve bu klasörün içeriğini yükleyin.
2. Depoda "Actions" sekmesine girin; "APK oluştur" iş akışı otomatik çalışır
   (veya "Run workflow" ile elle başlatın).
3. 5–8 dakika sonra işin sayfasında "adell-operator-apk" dosyasını indirin.
   İçindeki app-debug.apk tablete kurulacak dosyadır.

## Yol B – Android Studio ile
1. Node.js 18+ ve Android Studio kurun.
2. Bu klasörde komut satırında:  npm install   ardından   npx cap sync android
3. npx cap open android  (Android Studio açılır)
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. APK: android/app/build/outputs/apk/debug/app-debug.apk

## Tablete kurma
1. APK dosyasını tablete kopyalayın (USB, e-posta veya paylaşımlı klasör).
2. Dosyaya dokunun; "Bilinmeyen kaynaklardan yüklemeye izin ver" sorulursa izin verin.
3. "Adell Operatör" simgesiyle açın.

## Ekranları güncelleme
Tasarım değiştiğinde yalnızca www/index.html dosyası değişir. Yeni dosyayı koyup
Yol A'da depoya yükleyin (APK yeniden oluşur) veya Yol B'de npx cap sync android
çalıştırıp tekrar APK alın. Her yeni sürümde android/app/build.gradle içindeki
versionCode değerini 1 artırın.

## Not
- Bu bir "debug" APK'dır; tabletlere doğrudan kurmak için yeterlidir.
  Google Play veya kurumsal MDM ile dağıtım için imzalı "release" APK gerekir
  (Android Studio > Build > Generate Signed Bundle / APK).
- Veriler şu an demo verisidir. ERP, etiket yazıcısı ve makine sinyali
  entegrasyonu ayrıca yapılmalıdır.
